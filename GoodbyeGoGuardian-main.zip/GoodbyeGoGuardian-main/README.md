# GoodbyeGoGuardian
Kick GoGuardian to the curb!

## Dear skids reading this
Kindly pick a better exploit to skid
